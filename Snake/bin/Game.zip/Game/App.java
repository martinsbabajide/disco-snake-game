/*BY MARTINS BABAJIDE 
 * 100709716
 * REFERENCED FROM BroCode
 * Changes and updates Done  by Martins Babajide
 */


package Game;

public class App {

	
	public static void main(String[] args) {
		
		//creating an instance of the game frame class
		new GameFrame();

	}

}
